module SoftLeaks {
}