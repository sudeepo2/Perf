/**
 * 
 */
/**
 * @author Matt
 *
 */
module bookCatalog {
	exports main;
}