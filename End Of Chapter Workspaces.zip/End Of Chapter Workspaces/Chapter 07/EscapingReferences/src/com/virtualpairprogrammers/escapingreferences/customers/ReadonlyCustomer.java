package com.virtualpairprogrammers.escapingreferences.customers;

public interface ReadonlyCustomer {

	String getName();

	String toString();

}